#!/bin/bash
# ASh Project — One-Click Setup Script
# Run: chmod +x scripts/setup.sh && ./scripts/setup.sh

set -e

echo "╔══════════════════════════════════════╗"
echo "║     ASh — P&O AI Assistant Setup     ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Check Python
echo -e "${YELLOW}[1/6] Checking Python...${NC}"
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    echo -e "${GREEN}  ✓ Python $PYTHON_VERSION found${NC}"
else
    echo -e "${RED}  ✗ Python 3.11+ required. Install from python.org${NC}"
    exit 1
fi

# Check system dependencies
echo -e "${YELLOW}[2/6] Checking system dependencies...${NC}"
MISSING=""
if ! command -v tesseract &> /dev/null; then
    MISSING="$MISSING tesseract-ocr"
fi
if ! command -v pdftotext &> /dev/null; then
    MISSING="$MISSING poppler-utils"
fi

if [ -n "$MISSING" ]; then
    echo -e "${YELLOW}  Installing:$MISSING${NC}"
    if command -v apt-get &> /dev/null; then
        sudo apt-get update -qq && sudo apt-get install -y -qq $MISSING
    elif command -v brew &> /dev/null; then
        brew install tesseract poppler 2>/dev/null || true
    else
        echo -e "${RED}  ✗ Please install manually:$MISSING${NC}"
    fi
fi
echo -e "${GREEN}  ✓ System dependencies ready${NC}"

# Create virtual environment
echo -e "${YELLOW}[3/6] Creating virtual environment...${NC}"
cd backend
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate
echo -e "${GREEN}  ✓ Virtual environment active${NC}"

# Install Python dependencies
echo -e "${YELLOW}[4/6] Installing Python packages...${NC}"
pip install -q --upgrade pip
pip install -q -r requirements.txt
echo -e "${GREEN}  ✓ All packages installed${NC}"

# Setup environment
echo -e "${YELLOW}[5/6] Configuring environment...${NC}"
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "${YELLOW}  ⚠ Created .env file — EDIT IT with your API keys!${NC}"
    echo -e "${YELLOW}    → nano backend/.env${NC}"
else
    echo -e "${GREEN}  ✓ .env already exists${NC}"
fi

# Create data directories
mkdir -p data/uploads data/chromadb data/chunks

# Test the setup
echo -e "${YELLOW}[6/6] Testing setup...${NC}"
python3 -c "
from app.config import ANTHROPIC_API_KEY, CHROMA_PERSIST_DIR
print(f'  API Key: {\"configured\" if ANTHROPIC_API_KEY and ANTHROPIC_API_KEY != \"sk-ant-your-key-here\" else \"⚠ NOT SET — edit .env\"}')
print(f'  ChromaDB: {CHROMA_PERSIST_DIR}')
print('  ✓ All imports successful')
"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         Setup Complete! 🎉           ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════╝${NC}"
echo ""
echo "Next steps:"
echo "  1. Edit backend/.env with your ANTHROPIC_API_KEY"
echo "  2. cd backend && source venv/bin/activate"
echo "  3. uvicorn app.main:app --reload"
echo "  4. Open http://localhost:8000/docs"
echo ""
