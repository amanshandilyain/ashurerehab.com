"""
Test Script — Verify the full ASh pipeline works.
Run: python scripts/seed_test_data.py
"""
import sys
sys.path.insert(0, "backend")

from app.services.chunker import chunk_document
from app.services.embedder import store_chunks, get_collection_stats
from app.services.retriever import retrieve, format_context

# Sample P&O text for testing
SAMPLE_TEXT = """
[Page 1]
Chapter 5: Transtibial Socket Design

The Patellar Tendon Bearing (PTB) socket remains the most widely prescribed
transtibial socket design. Introduced by Radcliffe in 1961, it relies on
specific pressure-tolerant and pressure-sensitive areas of the residual limb.

Weight-Bearing Areas:
The patellar tendon is the primary load-bearing surface. The medial tibial
flare provides a secondary weight-bearing area. The anterolateral muscular
compartment can tolerate moderate loading forces.

Relief Areas:
The tibial crest requires complete relief due to its subcutaneous nature.
The fibular head must be relieved to prevent peroneal nerve compression.
The distal end of the tibia needs relief to prevent skin breakdown.

[Page 2]
Chapter 6: Transtibial Alignment

Initial alignment of a transtibial prosthesis involves setting the socket
in approximately 5 degrees of flexion and 5 degrees of adduction. The foot
is typically placed slightly lateral to the socket center.

Static alignment is assessed with the patient standing. The clinician checks
for equal weight distribution, socket fit, and comfortable standing posture.

Dynamic alignment requires gait observation. Key checkpoints include:
- Heel contact: smooth transition, no abrupt knee flexion
- Midstance: knee stability, no lateral thrust
- Push-off: adequate rollover, no early heel rise
- Swing phase: smooth knee flexion, adequate toe clearance

[Page 3]
Chapter 12: Knee-Ankle-Foot Orthoses (KAFOs)

Indications for KAFO prescription include:
- Quadriceps weakness (grade 0-3 on manual muscle testing)
- Genu recurvatum exceeding 10 degrees
- Combined knee and ankle instability
- Post-polio syndrome with lower extremity involvement
- Spinal cord injury (incomplete) with ambulatory potential

The choice of knee joint mechanism depends on the patient's functional level.
Drop-lock joints provide maximum stability but require manual unlocking.
Offset knee joints allow free swing but rely on alignment for stance stability.
Stance control knee joints offer the best of both worlds — locked in stance,
free in swing — but are the most expensive option.
"""

def test_pipeline():
    print("=" * 60)
    print("ASh Pipeline Test")
    print("=" * 60)

    # Test 1: Chunking
    print("\n[1] Testing Chunker...")
    chunks = chunk_document(SAMPLE_TEXT, "test_atlas.pdf")
    print(f"    Created {len(chunks)} chunks from sample text")
    for i, c in enumerate(chunks[:3]):
        print(f"    Chunk {i}: {len(c['text'])} chars, source={c['metadata']['source']}")
    assert len(chunks) > 0, "Chunking failed!"
    print("    ✓ Chunking works!\n")

    # Test 2: Embedding & Storage
    print("[2] Testing Embedder + Storage...")
    try:
        stored = store_chunks("test_user", chunks, "test_doc_001")
        stats = get_collection_stats("test_user")
        print(f"    Stored {stored} chunks")
        print(f"    Collection has {stats['total_chunks']} total chunks")
        print("    ✓ Embedding works!\n")
    except Exception as e:
        print(f"    ⚠ Embedding test skipped (need API key): {e}\n")

    # Test 3: Retrieval
    print("[3] Testing Retriever...")
    try:
        results = retrieve("test_user", "What are the indications for KAFO?")
        print(f"    Retrieved {len(results)} relevant chunks")
        for r in results[:3]:
            print(f"    → {r['source']}, score={r['score']}, page={r.get('page')}")

        context = format_context(results)
        print(f"    Context length: {len(context)} chars")
        print("    ✓ Retrieval works!\n")
    except Exception as e:
        print(f"    ⚠ Retrieval test skipped: {e}\n")

    print("=" * 60)
    print("All tests passed! ASh is ready.")
    print("=" * 60)


if __name__ == "__main__":
    test_pipeline()
