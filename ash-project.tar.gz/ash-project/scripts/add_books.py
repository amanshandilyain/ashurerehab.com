#!/usr/bin/env python3
"""
ASh Knowledge Base Manager — CLI Tool

Add books to ASh's knowledge base from the command line.

Usage:
    # Add a single book
    python scripts/add_books.py --file "Atlas of Prosthetics.pdf" --user myuser

    # Add all books from a folder
    python scripts/add_books.py --folder ./data/books --user myuser

    # Check knowledge base stats
    python scripts/add_books.py --stats --user myuser

    # List all documents
    python scripts/add_books.py --list --user myuser

    # Remove a document
    python scripts/add_books.py --remove doc_id --user myuser
"""
import os
import sys
import argparse
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from app.services.ingestion import extract_text
from app.services.chunker import chunk_document
from app.services.embedder import store_chunks, get_collection_stats, delete_document_chunks


SUPPORTED_EXTS = {".pdf", ".pptx", ".ppt", ".docx", ".doc", ".txt", ".md", ".csv", ".png", ".jpg", ".jpeg"}


def add_file(file_path: str, user_id: str) -> dict:
    """Process a single file and add it to the knowledge base."""
    filename = os.path.basename(file_path)
    doc_id = filename.replace(" ", "_").replace(".", "_")[:20]

    print(f"\n  📄 {filename}")
    print(f"     Extracting text...", end=" ", flush=True)

    t0 = time.time()
    result = extract_text(file_path)
    t_extract = time.time() - t0

    if not result["text"] or len(result["text"].strip()) < 50:
        print(f"❌ No text extracted ({result['method']})")
        return {"file": filename, "status": "failed", "reason": "no text"}

    print(f"✓ {result['pages']} pages, {len(result['text']):,} chars ({t_extract:.1f}s)")
    print(f"     Chunking...", end=" ", flush=True)

    t0 = time.time()
    chunks = chunk_document(result["text"], source_filename=filename)
    t_chunk = time.time() - t0

    print(f"✓ {len(chunks)} chunks ({t_chunk:.1f}s)")
    print(f"     Embedding & storing...", end=" ", flush=True)

    t0 = time.time()
    stored = store_chunks(user_id=user_id, chunks=chunks, document_id=doc_id)
    t_embed = time.time() - t0

    print(f"✓ {stored} vectors stored ({t_embed:.1f}s)")

    total_time = t_extract + t_chunk + t_embed
    print(f"     ✅ Done in {total_time:.1f}s")

    return {
        "file": filename, "status": "ready", "doc_id": doc_id,
        "pages": result["pages"], "chunks": len(chunks),
        "time": round(total_time, 1),
    }


def add_folder(folder_path: str, user_id: str):
    """Process all supported files in a folder."""
    if not os.path.isdir(folder_path):
        print(f"❌ Folder not found: {folder_path}")
        return

    files = []
    for root, dirs, fnames in os.walk(folder_path):
        for f in sorted(fnames):
            ext = os.path.splitext(f)[1].lower()
            if ext in SUPPORTED_EXTS:
                files.append(os.path.join(root, f))

    if not files:
        print(f"No supported files found in {folder_path}")
        return

    print(f"\n{'='*60}")
    print(f"  ASh Knowledge Base — Bulk Ingestion")
    print(f"  Folder: {folder_path}")
    print(f"  Files:  {len(files)}")
    print(f"  User:   {user_id}")
    print(f"{'='*60}")

    results = []
    total_start = time.time()

    for i, fpath in enumerate(files):
        print(f"\n  [{i+1}/{len(files)}]", end="")
        r = add_file(fpath, user_id)
        results.append(r)

    total_time = time.time() - total_start
    success = [r for r in results if r["status"] == "ready"]
    failed = [r for r in results if r["status"] != "ready"]
    total_chunks = sum(r.get("chunks", 0) for r in success)

    print(f"\n{'='*60}")
    print(f"  ✅ Complete!")
    print(f"  Processed: {len(success)}/{len(files)} files")
    print(f"  Total chunks: {total_chunks:,}")
    print(f"  Total time: {total_time:.1f}s")
    if failed:
        print(f"  ⚠ Failed: {len(failed)} files")
        for f in failed:
            print(f"     - {f['file']}: {f.get('reason', 'unknown')}")
    print(f"{'='*60}\n")


def show_stats(user_id: str):
    """Show knowledge base statistics."""
    stats = get_collection_stats(user_id)
    print(f"\n  📊 Knowledge Base Stats for '{user_id}'")
    print(f"  Total chunks:     {stats['total_chunks']:,}")
    print(f"  Collection:       {stats['collection_name']}")
    print(f"  Embedding cache:  {stats.get('embedding_cache_size', 0):,} entries")
    print()


def main():
    parser = argparse.ArgumentParser(description="ASh Knowledge Base Manager")
    parser.add_argument("--file", help="Path to a single file to add")
    parser.add_argument("--folder", help="Path to a folder of files to add")
    parser.add_argument("--user", default="default", help="User ID (default: 'default')")
    parser.add_argument("--stats", action="store_true", help="Show knowledge base stats")
    parser.add_argument("--remove", help="Remove a document by ID")

    args = parser.parse_args()

    if args.stats:
        show_stats(args.user)
    elif args.file:
        if not os.path.exists(args.file):
            print(f"❌ File not found: {args.file}")
            sys.exit(1)
        add_file(args.file, args.user)
        show_stats(args.user)
    elif args.folder:
        add_folder(args.folder, args.user)
        show_stats(args.user)
    elif args.remove:
        removed = delete_document_chunks(args.user, args.remove)
        print(f"  Removed {removed} chunks for document '{args.remove}'")
        show_stats(args.user)
    else:
        parser.print_help()
        print("\n  Quick start:")
        print("    python scripts/add_books.py --folder ./data/books --user myuser")
        print("    python scripts/add_books.py --file 'Atlas.pdf' --user myuser")
        print("    python scripts/add_books.py --stats --user myuser\n")


if __name__ == "__main__":
    main()
