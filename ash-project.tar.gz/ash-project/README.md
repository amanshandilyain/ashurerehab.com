# ASh — P&O Medical AI Assistant

> AI-powered study companion for Prosthetics & Orthotics professionals.  
> Upload textbooks. Ask questions. Get synthesized, cited answers.

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                   MOBILE / WEB UI                    │
│  (React Native / React)                              │
│  Upload docs │ Ask questions │ View answers + sources │
└──────────────────────┬──────────────────────────────┘
                       │ REST API
┌──────────────────────▼──────────────────────────────┐
│                  FASTAPI BACKEND                     │
│                                                      │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │  INGESTION   │  │  RETRIEVAL   │  │    LLM     │  │
│  │  PDF reader  │  │  Embed query │  │  Claude    │  │
│  │  PPTX reader │  │  Search DB   │  │  Haiku →   │  │
│  │  Image OCR   │  │  Rank chunks │  │  Sonnet    │  │
│  │  Chunking    │  │  Top-K pick  │  │  fallback  │  │
│  └──────┬──────┘  └──────┬───────┘  └─────┬──────┘  │
│         │                │                 │          │
│  ┌──────▼────────────────▼─────────────────▼───────┐ │
│  │              ChromaDB (Vector Store)             │ │
│  │  Embeddings + Metadata + Full chunk text         │ │
│  └─────────────────────────────────────────────────┘ │
│                                                      │
│  ┌─────────────────────────────────────────────────┐ │
│  │           PostgreSQL (User data, history)        │ │
│  └─────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────┘
```

---

## Folder Structure

```
ash-project/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py                 # FastAPI entry point
│   │   ├── config.py               # Environment & API keys
│   │   ├── routes/
│   │   │   ├── __init__.py
│   │   │   ├── auth.py             # Signup, login, JWT
│   │   │   ├── chat.py             # /ask endpoint
│   │   │   ├── documents.py        # Upload, list, delete docs
│   │   │   └── health.py           # Health check
│   │   ├── services/
│   │   │   ├── __init__.py
│   │   │   ├── ingestion.py        # PDF, PPTX, image readers
│   │   │   ├── chunker.py          # Smart text chunking
│   │   │   ├── embedder.py         # Generate embeddings
│   │   │   ├── retriever.py        # Vector search + reranking
│   │   │   ├── llm.py              # Claude API (Haiku/Sonnet)
│   │   │   └── ocr.py              # Image text extraction
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   ├── user.py             # User schema
│   │   │   ├── document.py         # Document metadata
│   │   │   └── conversation.py     # Chat history
│   │   └── middleware/
│   │       ├── __init__.py
│   │       └── auth_guard.py       # JWT verification
│   ├── tests/
│   │   ├── test_ingestion.py
│   │   ├── test_chunker.py
│   │   └── test_retriever.py
│   ├── data/
│   │   ├── uploads/                # Raw uploaded files
│   │   └── chunks/                 # Processed chunk cache
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/                       # React web UI (see ash-app.jsx)
├── scripts/
│   ├── setup.sh                    # One-click setup
│   └── seed_test_data.py           # Test with sample docs
├── docker-compose.yml
└── README.md                       # ← You are here
```

---

## Quick Start (5 minutes)

### Prerequisites
- Python 3.11+
- Node.js 18+ (for frontend)
- An Anthropic API key → https://console.anthropic.com

### 1. Clone & Setup

```bash
git clone https://github.com/your-org/ash-project.git
cd ash-project

# Run automated setup
chmod +x scripts/setup.sh
./scripts/setup.sh
```

### 2. Manual Setup (if you prefer)

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate        # Linux/Mac
# venv\Scripts\activate         # Windows

# Install Python dependencies
cd backend
pip install -r requirements.txt

# Install system deps for OCR
# Ubuntu/Debian:
sudo apt-get install tesseract-ocr poppler-utils
# Mac:
# brew install tesseract poppler

# Copy and fill environment variables
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

### 3. Start the Backend

```bash
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

API docs available at: `http://localhost:8000/docs`

### 4. Start the Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:3000`

### 5. Docker (Production)

```bash
docker-compose up -d
```

---

## API Endpoints

| Method | Endpoint                 | Description                         |
|--------|--------------------------|-------------------------------------|
| POST   | /auth/signup             | Create account                      |
| POST   | /auth/login              | Login, get JWT                      |
| POST   | /documents/upload        | Upload PDF/PPTX/image               |
| POST   | /documents/bulk-upload   | Upload multiple files at once       |
| POST   | /documents/ingest-folder | Ingest all files from a local folder|
| GET    | /documents/list          | List uploaded documents + stats     |
| DELETE | /documents/{id}          | Remove a document                   |
| POST   | /chat/ask                | Ask a question (RAG pipeline)       |
| GET    | /chat/history            | Get conversation history            |
| POST   | /vision/analyze          | Upload image + ask questions (OCR+Vision) |
| POST   | /vision/analyze-inline   | Quick image analysis (no disk save) |
| GET    | /health                  | Health check                        |

---

## Adding New Books to the Knowledge Base

### Method 1: Single Upload (API or UI)
```bash
curl -X POST http://localhost:8000/documents/upload \
  -F "file=@Atlas_of_Prosthetics.pdf" \
  -F "user_id=dr_khan"
```

### Method 2: Bulk Upload (multiple files at once)
```bash
curl -X POST http://localhost:8000/documents/bulk-upload \
  -F "files=@book1.pdf" \
  -F "files=@book2.pdf" \
  -F "files=@slides.pptx" \
  -F "user_id=dr_khan"
```

### Method 3: Folder Ingestion (best for large libraries)
```bash
# Place all books in data/books/
cp ~/textbooks/*.pdf data/books/

# Ingest entire folder
curl -X POST "http://localhost:8000/documents/ingest-folder?folder_path=data/books&user_id=dr_khan"
```

### Method 4: Programmatic (Python script)
```python
import httpx, os

API = "http://localhost:8000"
books_dir = "/path/to/my/textbooks"

for fname in os.listdir(books_dir):
    if fname.endswith(('.pdf', '.pptx', '.docx')):
        with open(os.path.join(books_dir, fname), 'rb') as f:
            httpx.post(f"{API}/documents/upload",
                files={"file": (fname, f)},
                data={"user_id": "dr_khan"})
        print(f"Uploaded: {fname}")
```

### What happens when you add a book:
```
Upload → Extract text (PDF/PPTX/OCR) → Detect chapters/pages
  → Chunk into ~1500 char pieces with 200 overlap
  → Batch-embed (64 at a time via OpenAI)
  → Store in ChromaDB with metadata (book, chapter, page)
  → Ready to query in 1-3 minutes per 100 pages
```

---

## Image Analysis

ASh can analyze images using OCR + Claude Vision:

```bash
# Analyze a prosthetic socket photo
curl -X POST http://localhost:8000/vision/analyze \
  -F "image=@socket_photo.jpg" \
  -F "question=What type of socket is this and how is the alignment?"

# Analyze a textbook diagram
curl -X POST http://localhost:8000/vision/analyze \
  -F "image=@gait_cycle_diagram.png" \
  -F "question=Explain each phase shown in this gait cycle diagram"
```

---

## How a Question Gets Answered

```
User asks: "What are the indications for a KAFO?"
    │
    ▼
1. EMBED the question → [0.23, -0.11, 0.87, ...] (1536-dim vector)
    │
    ▼
2. SEARCH ChromaDB → Find top 6 chunks with highest cosine similarity
    │
    ▼
3. RANK chunks by relevance score, deduplicate sources
    │
    ▼
4. BUILD prompt:
   System: "You are ASh... synthesize in your own words..."
   Context: [6 relevant chunks with source metadata]
   Question: "What are the indications for a KAFO?"
    │
    ▼
5. ROUTE to model:
   Simple question → Claude Haiku (fast, ~1-2s)
   Complex question → Claude Sonnet (deep, ~3-5s)
    │
    ▼
6. RETURN answer with source citations to user
```

---

## Environment Variables

```env
ANTHROPIC_API_KEY=sk-ant-...
CHROMA_PERSIST_DIR=./data/chromadb
UPLOAD_DIR=./data/uploads
DATABASE_URL=sqlite:///./data/ash.db
JWT_SECRET=your-secret-key-here
EMBEDDING_MODEL=text-embedding-3-small
```

---

## License

MIT — Built for the P&O community.
