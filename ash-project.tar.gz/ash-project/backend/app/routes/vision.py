"""Vision Route — Upload images and ask questions about them."""
import os
import uuid
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from app.config import UPLOAD_DIR, VISION_MAX_IMAGE_SIZE_MB, SUPPORTED_IMAGE_TYPES
from app.services.vision import analyze_image, analyze_image_bytes

router = APIRouter()


class VisionResponse(BaseModel):
    analysis: str
    ocr_text: str = ""
    model_used: str = ""
    image_id: str = ""


@router.post("/analyze", response_model=VisionResponse)
async def analyze_uploaded_image(
    image: UploadFile = File(...),
    question: str = Form(default="Analyze this image in detail."),
    user_id: str = Form(default="default"),
    user_name: str = Form(default="Clinician"),
    user_qualification: str = Form(default=""),
    user_specialization: str = Form(default="P&O"),
):
    """
    Upload an image and ask ASh to analyze it.

    Supports: PNG, JPG, JPEG, GIF, WEBP, TIFF
    Use cases:
    - Medical textbook diagrams
    - Prosthetic/orthotic design photos
    - X-rays and gait screenshots
    - Scanned handwritten notes
    """
    if not image.filename:
        raise HTTPException(400, "No image provided")

    ext = os.path.splitext(image.filename)[1].lower()
    if ext not in SUPPORTED_IMAGE_TYPES:
        raise HTTPException(400, f"Unsupported image type: {ext}. Supported: {', '.join(SUPPORTED_IMAGE_TYPES)}")

    contents = await image.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > VISION_MAX_IMAGE_SIZE_MB:
        raise HTTPException(400, f"Image too large ({size_mb:.1f}MB). Max: {VISION_MAX_IMAGE_SIZE_MB}MB")

    # Save image
    img_id = str(uuid.uuid4())[:8]
    safe_name = f"img_{img_id}{ext}"
    img_path = os.path.join(UPLOAD_DIR, safe_name)

    with open(img_path, "wb") as f:
        f.write(contents)

    # Analyze with OCR + Vision
    result = analyze_image(
        image_path=img_path,
        question=question,
        user_name=user_name,
        user_qualification=user_qualification,
        user_specialization=user_specialization,
    )

    return VisionResponse(
        analysis=result["analysis"],
        ocr_text=result.get("ocr_text", ""),
        model_used=result.get("model_used", ""),
        image_id=img_id,
    )


@router.post("/analyze-inline", response_model=VisionResponse)
async def analyze_inline_image(
    image: UploadFile = File(...),
    question: str = Form(default="What is shown in this image?"),
    user_name: str = Form(default="Clinician"),
):
    """
    Quick image analysis without saving to disk.
    Faster for one-off questions about images.
    """
    contents = await image.read()
    ext = os.path.splitext(image.filename or "img.png")[1].lower()

    mime_map = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".gif": "image/gif", ".webp": "image/webp"}
    media_type = mime_map.get(ext, "image/png")

    result = analyze_image_bytes(
        image_bytes=contents,
        media_type=media_type,
        question=question,
        user_name=user_name,
    )

    return VisionResponse(
        analysis=result["analysis"],
        ocr_text=result.get("ocr_text", ""),
        model_used=result.get("model_used", ""),
    )
