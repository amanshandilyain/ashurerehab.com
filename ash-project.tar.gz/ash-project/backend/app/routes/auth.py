"""Authentication Routes — Signup, Login, JWT."""
from datetime import datetime, timedelta
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from passlib.context import CryptContext
from jose import jwt
from app.config import JWT_SECRET, JWT_ALGORITHM, JWT_EXPIRY_DAYS

router = APIRouter()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# In-memory user store (use PostgreSQL in production)
users_db: dict[str, dict] = {}


class SignupRequest(BaseModel):
    email: str
    password: str
    full_name: str = ""
    phone: str = ""
    country: str = ""
    city: str = ""
    qualification: str = ""
    specialization: str = ""
    institution: str = ""
    license_number: str = ""
    years_experience: str = ""


class LoginRequest(BaseModel):
    email: str
    password: str


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    full_name: str


@router.post("/signup", response_model=AuthResponse)
async def signup(req: SignupRequest):
    if req.email in users_db:
        raise HTTPException(400, "Email already registered")

    user_id = req.email.split("@")[0].replace(".", "_")
    users_db[req.email] = {
        "id": user_id,
        "email": req.email,
        "password_hash": pwd_context.hash(req.password),
        "full_name": req.full_name,
        "phone": req.phone,
        "country": req.country,
        "city": req.city,
        "qualification": req.qualification,
        "specialization": req.specialization,
        "institution": req.institution,
        "license_number": req.license_number,
        "years_experience": req.years_experience,
    }

    token = jwt.encode(
        {"sub": user_id, "exp": datetime.utcnow() + timedelta(days=JWT_EXPIRY_DAYS)},
        JWT_SECRET, algorithm=JWT_ALGORITHM,
    )

    return AuthResponse(access_token=token, user_id=user_id, full_name=req.full_name)


@router.post("/login", response_model=AuthResponse)
async def login(req: LoginRequest):
    user = users_db.get(req.email)
    if not user or not pwd_context.verify(req.password, user["password_hash"]):
        raise HTTPException(401, "Invalid credentials")

    token = jwt.encode(
        {"sub": user["id"], "exp": datetime.utcnow() + timedelta(days=JWT_EXPIRY_DAYS)},
        JWT_SECRET, algorithm=JWT_ALGORITHM,
    )

    return AuthResponse(access_token=token, user_id=user["id"], full_name=user["full_name"])
