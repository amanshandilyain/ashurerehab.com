"""
Admin Dashboard Routes
Gives you visibility into system health, usage patterns, and user management
WITHOUT accessing private conversations or personal data.

What you CAN see:
  - Total users, signups over time, active users
  - Questions asked per day/week/month (counts, not content)
  - Most popular topics (aggregated, anonymized)
  - Document upload stats (counts, sizes, types — not content)
  - System health (API latency, error rates, storage usage)
  - Per-user usage stats (question count, doc count — not content)

What you CANNOT see:
  - Individual conversation content
  - User contacts or personal files
  - Specific questions users asked
  - Contents of uploaded documents

WHY: Medical professionals will only trust ASh if their data is private.
Trust = retention = growth. Privacy IS your competitive advantage.
"""
import os
import time
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from app.config import UPLOAD_DIR, CHROMA_PERSIST_DIR

router = APIRouter()

# ─── ADMIN AUTH (simple key-based, upgrade to proper RBAC in production) ─────
ADMIN_KEY = os.getenv("ASH_ADMIN_KEY", "ash-admin-change-this-key")

def verify_admin(admin_key: str):
    if admin_key != ADMIN_KEY:
        raise HTTPException(403, "Invalid admin key")
    return True


# ─── ANALYTICS STORAGE (in-memory, replace with DB in production) ────────────
# These track COUNTS only, never content
analytics = {
    "total_questions": 0,
    "total_uploads": 0,
    "total_image_analyses": 0,
    "questions_today": 0,
    "errors_today": 0,
    "last_reset": datetime.now().isoformat(),
    "daily_questions": {},    # {"2026-03-09": 42}
    "popular_topics": {},     # {"socket_design": 15, "gait": 23} — from keywords, not content
    "model_usage": {"haiku": 0, "sonnet": 0},
    "avg_response_ms": 0,
    "response_times": [],     # Last 100 response times for avg calculation
}

def track_question(model_used: str, response_time_ms: float, question_keywords: list[str]):
    """Track aggregated question metrics. Never stores the actual question."""
    analytics["total_questions"] += 1
    analytics["questions_today"] += 1

    today = datetime.now().strftime("%Y-%m-%d")
    analytics["daily_questions"][today] = analytics["daily_questions"].get(today, 0) + 1

    if "haiku" in model_used.lower():
        analytics["model_usage"]["haiku"] += 1
    else:
        analytics["model_usage"]["sonnet"] += 1

    analytics["response_times"].append(response_time_ms)
    if len(analytics["response_times"]) > 100:
        analytics["response_times"] = analytics["response_times"][-100:]
    analytics["avg_response_ms"] = sum(analytics["response_times"]) / len(analytics["response_times"])

    # Track topic popularity from keywords (anonymized)
    for kw in question_keywords[:3]:  # Only top 3 keywords per question
        if len(kw) > 3:
            analytics["popular_topics"][kw] = analytics["popular_topics"].get(kw, 0) + 1

def track_upload():
    analytics["total_uploads"] += 1

def track_error():
    analytics["errors_today"] += 1


# ─── ADMIN ENDPOINTS ─────────────────────────────────────────────────────────

class DashboardResponse(BaseModel):
    total_users: int
    total_questions: int
    total_uploads: int
    total_image_analyses: int
    questions_today: int
    errors_today: int
    avg_response_ms: float
    model_usage: dict
    popular_topics: list[dict]
    daily_trend: list[dict]
    storage_usage: dict
    system_health: dict


@router.get("/dashboard", response_model=DashboardResponse)
async def admin_dashboard(admin_key: str):
    """
    Main admin dashboard — aggregated metrics only.
    No private data exposed.
    """
    verify_admin(admin_key)

    # Import here to avoid circular deps
    from app.routes.auth import users_db
    from app.routes.documents import documents_db

    # Count users
    total_users = len(users_db)

    # Storage usage
    upload_size = _get_dir_size(UPLOAD_DIR)
    chroma_size = _get_dir_size(CHROMA_PERSIST_DIR)

    # Popular topics (top 20, anonymized)
    sorted_topics = sorted(analytics["popular_topics"].items(), key=lambda x: x[1], reverse=True)[:20]
    popular = [{"topic": t, "count": c} for t, c in sorted_topics]

    # Daily trend (last 30 days)
    daily = sorted(analytics["daily_questions"].items())[-30:]
    trend = [{"date": d, "questions": c} for d, c in daily]

    return DashboardResponse(
        total_users=total_users,
        total_questions=analytics["total_questions"],
        total_uploads=analytics["total_uploads"],
        total_image_analyses=analytics["total_image_analyses"],
        questions_today=analytics["questions_today"],
        errors_today=analytics["errors_today"],
        avg_response_ms=round(analytics["avg_response_ms"], 1),
        model_usage=analytics["model_usage"],
        popular_topics=popular,
        daily_trend=trend,
        storage_usage={
            "uploads_mb": round(upload_size / (1024 * 1024), 1),
            "vector_db_mb": round(chroma_size / (1024 * 1024), 1),
            "total_mb": round((upload_size + chroma_size) / (1024 * 1024), 1),
        },
        system_health={
            "status": "healthy",
            "uptime_hours": round((time.time() - _start_time) / 3600, 1),
            "python_memory_mb": _get_process_memory(),
        },
    )


class UserSummary(BaseModel):
    user_id: str
    email: str
    full_name: str
    qualification: str
    specialization: str
    documents_count: int
    signup_date: str


@router.get("/users")
async def list_users(admin_key: str):
    """
    List users with USAGE stats only.
    Shows: name, qualification, doc count.
    Does NOT show: conversations, contacts, file contents.
    """
    verify_admin(admin_key)

    from app.routes.auth import users_db
    from app.routes.documents import documents_db

    users = []
    for email, u in users_db.items():
        uid = u["id"]
        doc_count = len(documents_db.get(uid, []))
        users.append(UserSummary(
            user_id=uid,
            email=email,
            full_name=u.get("full_name", ""),
            qualification=u.get("qualification", ""),
            specialization=u.get("specialization", ""),
            documents_count=doc_count,
            signup_date=u.get("created_at", "unknown"),
        ))

    return {"total": len(users), "users": users}


@router.get("/system")
async def system_info(admin_key: str):
    """Detailed system health for debugging."""
    verify_admin(admin_key)

    return {
        "storage": {
            "upload_dir": UPLOAD_DIR,
            "upload_size_mb": round(_get_dir_size(UPLOAD_DIR) / (1024*1024), 1),
            "vector_db_dir": CHROMA_PERSIST_DIR,
            "vector_db_size_mb": round(_get_dir_size(CHROMA_PERSIST_DIR) / (1024*1024), 1),
        },
        "performance": {
            "avg_response_ms": round(analytics["avg_response_ms"], 1),
            "last_10_response_ms": analytics["response_times"][-10:],
            "model_usage": analytics["model_usage"],
        },
        "config": {
            "haiku_model": os.getenv("HAIKU_MODEL", "claude-haiku-4-5-20251001"),
            "sonnet_model": os.getenv("SONNET_MODEL", "claude-sonnet-4-20250514"),
            "chunk_size": int(os.getenv("CHUNK_SIZE", "1500")),
            "top_k_chunks": int(os.getenv("TOP_K_CHUNKS", "6")),
        },
    }


@router.post("/reset-daily")
async def reset_daily_counters(admin_key: str):
    """Reset daily counters (run via cron at midnight)."""
    verify_admin(admin_key)
    analytics["questions_today"] = 0
    analytics["errors_today"] = 0
    analytics["last_reset"] = datetime.now().isoformat()
    return {"status": "reset", "timestamp": analytics["last_reset"]}


# ═════════════════════════════════════════════════════════════════════════════
# CONSENT-BASED FEATURES
# All features below require explicit user consent before data is accessible.
# Consent is per-feature, revocable anytime, and logged.
# ═════════════════════════════════════════════════════════════════════════════

# ─── USER CONSENT STORE ──────────────────────────────────────────────────────
# Tracks what each user has consented to. In production, use PostgreSQL.
user_consents: dict[str, dict] = {}
# Structure: {"user_id": {"support_access": True, "contact_sharing": True, "granted_at": "..."}}

# ─── SHARED CONTACTS STORE ───────────────────────────────────────────────────
shared_contacts: dict[str, list[dict]] = {}
# Structure: {"user_id": [{"name": "Dr. Khan", "phone": "+91...", "email": "..."}]}

# ─── SUPPORT CONVERSATION STORE ──────────────────────────────────────────────
# Only populated when a user explicitly shares their conversation for support
support_shared_chats: dict[str, dict] = {}
# Structure: {"user_id": {"messages": [...], "shared_at": "...", "reason": "..."}}


class ConsentRequest(BaseModel):
    user_id: str
    consent_type: str   # "support_access" | "contact_sharing"
    granted: bool       # True = opt in, False = revoke


class ContactEntry(BaseModel):
    name: str
    phone: str = ""
    email: str = ""
    profession: str = ""


class ShareForSupportRequest(BaseModel):
    user_id: str
    messages: list[dict]    # The user sends their own conversation
    reason: str = ""        # "App crashed", "Wrong answer", etc.


# ─── USER-FACING: Consent management ─────────────────────────────────────────

@router.post("/consent")
async def update_consent(req: ConsentRequest):
    """
    USER-FACING endpoint.
    Users explicitly grant or revoke consent for specific features.
    Called from the app's Settings screen.
    """
    if req.consent_type not in ("support_access", "contact_sharing"):
        raise HTTPException(400, "Invalid consent type. Use: support_access or contact_sharing")

    if req.user_id not in user_consents:
        user_consents[req.user_id] = {}

    user_consents[req.user_id][req.consent_type] = req.granted
    user_consents[req.user_id][f"{req.consent_type}_updated"] = datetime.now().isoformat()

    action = "granted" if req.granted else "revoked"

    # If revoking contact sharing, delete their shared contacts
    if req.consent_type == "contact_sharing" and not req.granted:
        shared_contacts.pop(req.user_id, None)

    # If revoking support access, delete any shared conversations
    if req.consent_type == "support_access" and not req.granted:
        support_shared_chats.pop(req.user_id, None)

    return {
        "user_id": req.user_id,
        "consent_type": req.consent_type,
        "status": action,
        "message": f"You have {action} consent for {req.consent_type.replace('_', ' ')}."
            + (" Your shared data has been deleted." if not req.granted else ""),
    }


@router.get("/consent/{user_id}")
async def get_consent_status(user_id: str):
    """USER-FACING: Check what a user has consented to."""
    consents = user_consents.get(user_id, {})
    return {
        "user_id": user_id,
        "support_access": consents.get("support_access", False),
        "contact_sharing": consents.get("contact_sharing", False),
    }


# ─── USER-FACING: Share contacts (opt-in referral) ───────────────────────────

@router.post("/share-contacts")
async def share_contacts_endpoint(user_id: str, contacts: list[ContactEntry]):
    """
    USER-FACING: User voluntarily shares professional contacts.
    Only works if the user has granted 'contact_sharing' consent.
    Used to invite fellow P&O professionals to try ASh.
    """
    consents = user_consents.get(user_id, {})
    if not consents.get("contact_sharing"):
        raise HTTPException(403,
            "Contact sharing not enabled. Please grant consent in Settings first.")

    # Store contacts (per user, isolated)
    if user_id not in shared_contacts:
        shared_contacts[user_id] = []

    for c in contacts:
        # Avoid duplicates
        existing_phones = {e["phone"] for e in shared_contacts[user_id] if e.get("phone")}
        if c.phone and c.phone not in existing_phones:
            shared_contacts[user_id].append({
                "name": c.name,
                "phone": c.phone,
                "email": c.email,
                "profession": c.profession,
                "shared_at": datetime.now().isoformat(),
            })

    return {
        "stored": len(contacts),
        "total_contacts": len(shared_contacts[user_id]),
        "message": "Contacts saved. We'll send a one-time professional invitation on your behalf.",
    }


# ─── USER-FACING: Share conversation for support ─────────────────────────────

@router.post("/share-for-support")
async def share_conversation_for_support(req: ShareForSupportRequest):
    """
    USER-FACING: User explicitly shares their conversation so the
    admin/support team can troubleshoot their issue.

    This is the ONLY way admin can see conversation content.
    The user initiates the sharing — admin cannot pull it.
    """
    consents = user_consents.get(req.user_id, {})
    if not consents.get("support_access"):
        raise HTTPException(403,
            "Support access not enabled. Please grant consent in Settings first.")

    support_shared_chats[req.user_id] = {
        "messages": req.messages,
        "reason": req.reason,
        "shared_at": datetime.now().isoformat(),
        "message_count": len(req.messages),
    }

    return {
        "status": "shared",
        "message": f"Your conversation ({len(req.messages)} messages) has been shared with ASh support. "
                   "We'll review it and get back to you. You can revoke access anytime in Settings.",
    }


# ─── ADMIN: View support-shared conversations ────────────────────────────────

@router.get("/support-tickets")
async def get_support_tickets(admin_key: str):
    """
    ADMIN: View conversations that users have voluntarily shared for support.
    Only shows chats where the user clicked "Share with Support".
    """
    verify_admin(admin_key)

    tickets = []
    for user_id, data in support_shared_chats.items():
        tickets.append({
            "user_id": user_id,
            "reason": data.get("reason", ""),
            "message_count": data.get("message_count", 0),
            "shared_at": data.get("shared_at", ""),
        })

    return {"total_tickets": len(tickets), "tickets": tickets}


@router.get("/support-tickets/{user_id}")
async def get_support_ticket_detail(user_id: str, admin_key: str):
    """
    ADMIN: View the actual conversation content for a specific support ticket.
    Only available if the user has actively shared it.
    """
    verify_admin(admin_key)

    if user_id not in support_shared_chats:
        raise HTTPException(404, "No support ticket from this user. "
            "Users must share their conversation via the app before you can view it.")

    return support_shared_chats[user_id]


# ─── ADMIN: View shared contacts for referral campaigns ──────────────────────

@router.get("/referral-contacts")
async def get_referral_contacts(admin_key: str):
    """
    ADMIN: View contacts that users have voluntarily shared for referrals.
    Only shows contacts from users who opted in to contact_sharing.
    """
    verify_admin(admin_key)

    all_contacts = []
    for user_id, contacts in shared_contacts.items():
        for c in contacts:
            all_contacts.append({
                **c,
                "referred_by": user_id,
            })

    return {
        "total_contacts": len(all_contacts),
        "unique_users_sharing": len(shared_contacts),
        "contacts": all_contacts,
    }


@router.get("/referral-stats")
async def referral_stats(admin_key: str):
    """ADMIN: Referral program overview."""
    verify_admin(admin_key)

    total_contacts = sum(len(c) for c in shared_contacts.values())
    users_sharing = len(shared_contacts)
    users_with_support = sum(
        1 for c in user_consents.values() if c.get("support_access")
    )
    users_with_contacts = sum(
        1 for c in user_consents.values() if c.get("contact_sharing")
    )

    return {
        "total_shared_contacts": total_contacts,
        "users_sharing_contacts": users_sharing,
        "users_with_support_consent": users_with_support,
        "users_with_contact_consent": users_with_contacts,
    }


# ─── HELPERS ─────────────────────────────────────────────────────────────────

_start_time = time.time()

def _get_dir_size(path: str) -> int:
    total = 0
    if os.path.exists(path):
        for dirpath, dirnames, filenames in os.walk(path):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    total += os.path.getsize(fp)
                except OSError:
                    pass
    return total

def _get_process_memory() -> float:
    try:
        import resource
        return round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1)
    except Exception:
        return 0.0
