"""Document Upload & Management Routes."""
import os
import uuid
from fastapi import APIRouter, UploadFile, File, BackgroundTasks, HTTPException
from pydantic import BaseModel
from app.config import UPLOAD_DIR, MAX_UPLOAD_SIZE_MB
from app.services.ingestion import extract_text
from app.services.chunker import chunk_document
from app.services.embedder import store_chunks, delete_document_chunks, get_collection_stats

router = APIRouter()

# In-memory document registry (use DB in production)
documents_db: dict[str, list[dict]] = {}


class DocumentInfo(BaseModel):
    id: str
    filename: str
    status: str  # processing, ready, failed
    pages: int = 0
    chunks: int = 0
    method: str = ""


class UploadResponse(BaseModel):
    document_id: str
    filename: str
    status: str
    message: str


@router.post("/upload", response_model=UploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    user_id: str = "default",
    background_tasks: BackgroundTasks = None,
):
    """Upload a document for processing."""
    # Validate
    if not file.filename:
        raise HTTPException(400, "No filename provided")

    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > MAX_UPLOAD_SIZE_MB:
        raise HTTPException(400, f"File too large ({size_mb:.1f}MB). Max: {MAX_UPLOAD_SIZE_MB}MB")

    # Save file
    doc_id = str(uuid.uuid4())[:8]
    safe_name = f"{doc_id}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, safe_name)

    with open(file_path, "wb") as f:
        f.write(contents)

    # Register document
    doc_info = {
        "id": doc_id,
        "filename": file.filename,
        "file_path": file_path,
        "status": "processing",
        "pages": 0,
        "chunks": 0,
        "method": "",
    }

    if user_id not in documents_db:
        documents_db[user_id] = []
    documents_db[user_id].append(doc_info)

    # Process in background
    background_tasks.add_task(process_document, user_id, doc_id, file_path, file.filename)

    return UploadResponse(
        document_id=doc_id,
        filename=file.filename,
        status="processing",
        message=f"'{file.filename}' is being processed. This may take 1-3 minutes for large files.",
    )


async def process_document(user_id: str, doc_id: str, file_path: str, filename: str):
    """Background task: extract text, chunk, embed, store."""
    doc = next((d for d in documents_db.get(user_id, []) if d["id"] == doc_id), None)
    if not doc:
        return

    try:
        # Step 1: Extract text
        result = extract_text(file_path)
        doc["pages"] = result["pages"]
        doc["method"] = result["method"]

        if not result["text"] or len(result["text"].strip()) < 50:
            doc["status"] = "failed"
            doc["method"] = f"No text extracted ({result['method']})"
            return

        # Step 2: Chunk
        chunks = chunk_document(result["text"], source_filename=filename)
        doc["chunks"] = len(chunks)

        if not chunks:
            doc["status"] = "failed"
            doc["method"] = "No chunks generated"
            return

        # Step 3: Embed & store in vector DB
        stored = store_chunks(user_id=user_id, chunks=chunks, document_id=doc_id)

        doc["status"] = "ready"

    except Exception as e:
        doc["status"] = "failed"
        doc["method"] = f"Error: {str(e)}"


@router.get("/list")
async def list_documents(user_id: str = "default"):
    """List all documents for a user."""
    docs = documents_db.get(user_id, [])
    stats = get_collection_stats(user_id)
    return {
        "documents": [DocumentInfo(**{k: v for k, v in d.items() if k != "file_path"}) for d in docs],
        "total_chunks": stats["total_chunks"],
    }


@router.delete("/{doc_id}")
async def delete_document(doc_id: str, user_id: str = "default"):
    """Delete a document and its chunks."""
    docs = documents_db.get(user_id, [])
    doc = next((d for d in docs if d["id"] == doc_id), None)
    if not doc:
        raise HTTPException(404, "Document not found")

    removed = delete_document_chunks(user_id, doc_id)

    if os.path.exists(doc.get("file_path", "")):
        os.remove(doc["file_path"])

    documents_db[user_id] = [d for d in docs if d["id"] != doc_id]

    return {"deleted": doc_id, "chunks_removed": removed}


# ─── BULK UPLOAD — Add many books at once ────────────────────────────────────

@router.post("/bulk-upload")
async def bulk_upload(
    files: list[UploadFile] = File(...),
    user_id: str = "default",
    background_tasks: BackgroundTasks = None,
):
    """
    Upload multiple documents at once.
    All files are processed in parallel in the background.
    """
    results = []
    for file in files:
        if not file.filename:
            continue

        contents = await file.read()
        size_mb = len(contents) / (1024 * 1024)
        if size_mb > MAX_UPLOAD_SIZE_MB:
            results.append({"filename": file.filename, "status": "rejected", "reason": f"Too large ({size_mb:.1f}MB)"})
            continue

        doc_id = str(uuid.uuid4())[:8]
        safe_name = f"{doc_id}_{file.filename}"
        file_path = os.path.join(UPLOAD_DIR, safe_name)

        with open(file_path, "wb") as f:
            f.write(contents)

        doc_info = {
            "id": doc_id, "filename": file.filename, "file_path": file_path,
            "status": "processing", "pages": 0, "chunks": 0, "method": "",
        }
        if user_id not in documents_db:
            documents_db[user_id] = []
        documents_db[user_id].append(doc_info)

        background_tasks.add_task(process_document, user_id, doc_id, file_path, file.filename)
        results.append({"filename": file.filename, "document_id": doc_id, "status": "processing"})

    return {
        "uploaded": len([r for r in results if r["status"] == "processing"]),
        "rejected": len([r for r in results if r["status"] == "rejected"]),
        "documents": results,
    }


@router.post("/ingest-folder")
async def ingest_folder(
    folder_path: str,
    user_id: str = "default",
    background_tasks: BackgroundTasks = None,
):
    """
    Ingest all supported files from a local folder.
    Use this to bulk-load an entire textbook library.

    Place books in: data/books/
    Then call: POST /documents/ingest-folder?folder_path=data/books&user_id=myuser

    Supported: .pdf, .pptx, .docx, .txt, .md, .csv, .png, .jpg
    """
    from app.config import BULK_UPLOAD_DIR

    # Resolve path (allow relative from project root)
    if not os.path.isabs(folder_path):
        folder_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), folder_path)

    if not os.path.isdir(folder_path):
        raise HTTPException(404, f"Folder not found: {folder_path}")

    SUPPORTED_EXTS = {".pdf", ".pptx", ".ppt", ".docx", ".doc", ".txt", ".md", ".csv", ".png", ".jpg", ".jpeg"}

    queued = []
    for root, dirs, files in os.walk(folder_path):
        for fname in sorted(files):
            ext = os.path.splitext(fname)[1].lower()
            if ext not in SUPPORTED_EXTS:
                continue

            file_path = os.path.join(root, fname)
            doc_id = str(uuid.uuid4())[:8]

            doc_info = {
                "id": doc_id, "filename": fname, "file_path": file_path,
                "status": "processing", "pages": 0, "chunks": 0, "method": "",
            }
            if user_id not in documents_db:
                documents_db[user_id] = []
            documents_db[user_id].append(doc_info)

            background_tasks.add_task(process_document, user_id, doc_id, file_path, fname)
            queued.append({"filename": fname, "document_id": doc_id})

    return {
        "folder": folder_path,
        "files_queued": len(queued),
        "documents": queued,
        "message": f"Processing {len(queued)} files in the background. Check /documents/list for status.",
    }
