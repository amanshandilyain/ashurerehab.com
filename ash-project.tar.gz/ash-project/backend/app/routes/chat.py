"""Chat Route — Q&A + Image Analysis endpoints."""
import base64
from fastapi import APIRouter, UploadFile, File, Form
from pydantic import BaseModel
from app.services.retriever import retrieve, format_context, get_retrieval_summary
from app.services.llm import generate_answer
from app.services.vision import analyze_image_from_base64

router = APIRouter()


class AskRequest(BaseModel):
    question: str
    user_id: str = "default"
    user_name: str = "Clinician"
    user_qualification: str = "P&O Professional"
    user_specialization: str = "P&O"
    conversation_history: list[dict] = []


class SourceRef(BaseModel):
    book_name: str
    chapter: str | None = None
    section: str | None = None
    page: int | None = None
    relevance: float = 0.0
    content_type: str = "prose"


class AskResponse(BaseModel):
    answer: str
    sources: list[SourceRef]
    model_used: str
    chunks_retrieved: int
    tokens_used: int
    retrieval_summary: dict = {}


class ImageAnalysisResponse(BaseModel):
    analysis: str
    ocr_text: str | None = None
    model_used: str
    tokens_used: int


# ─── TEXT Q&A ────────────────────────────────────────────────────────────────

@router.post("/ask", response_model=AskResponse)
async def ask_ash(req: AskRequest):
    """
    Q&A pipeline:
    1. Hybrid retrieval (semantic + keyword)
    2. Rich context with book/chapter/page metadata
    3. Haiku (fast) or Sonnet (deep) routing
    4. Synthesized answer with source citations
    """
    chunks = retrieve(user_id=req.user_id, query=req.question)
    context = format_context(chunks)

    result = await generate_answer(
        question=req.question, context=context,
        user_name=req.user_name, user_qualification=req.user_qualification,
        user_specialization=req.user_specialization,
        conversation_history=req.conversation_history,
    )

    sources = []
    seen = set()
    for chunk in chunks:
        key = f"{chunk.get('book_name', '')}|{chunk.get('chapter', '')}|{chunk.get('page', '')}"
        if key not in seen:
            seen.add(key)
            sources.append(SourceRef(
                book_name=chunk.get("book_name", chunk.get("source", "Unknown")),
                chapter=chunk.get("chapter"), section=chunk.get("section"),
                page=chunk.get("page"), relevance=chunk.get("score", 0),
                content_type=chunk.get("content_type", "prose"),
            ))

    return AskResponse(
        answer=result["answer"], sources=sources, model_used=result["model_used"],
        chunks_retrieved=len(chunks),
        tokens_used=result.get("tokens_in", 0) + result.get("tokens_out", 0),
        retrieval_summary=get_retrieval_summary(chunks),
    )


# ─── IMAGE ANALYSIS ─────────────────────────────────────────────────────────

@router.post("/analyze-image", response_model=ImageAnalysisResponse)
async def analyze_image_endpoint(
    image: UploadFile = File(...),
    question: str = Form(default=None),
    user_name: str = Form(default="Clinician"),
    user_specialization: str = Form(default="P&O"),
):
    """
    Upload an image for ASh to analyze.

    Supports: medical diagrams, prosthetic designs, scanned pages,
    clinical photos, X-rays (educational only).
    """
    contents = await image.read()
    if len(contents) / (1024 * 1024) > 20:
        return ImageAnalysisResponse(analysis="Image too large (max 20MB).", model_used="error", tokens_used=0)

    ext = (image.filename or "").rsplit(".", 1)[-1].lower()
    media_types = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}
    media_type = media_types.get(ext, "image/jpeg")

    b64_data = base64.standard_b64encode(contents).decode("utf-8")
    result = analyze_image_from_base64(
        base64_data=b64_data, media_type=media_type,
        question=question, user_name=user_name, user_specialization=user_specialization,
    )

    return ImageAnalysisResponse(
        analysis=result["analysis"], ocr_text=result.get("ocr_text"),
        model_used=result["model_used"],
        tokens_used=result.get("tokens_in", 0) + result.get("tokens_out", 0),
    )


# ─── COMBINED: IMAGE + RAG ──────────────────────────────────────────────────

@router.post("/ask-with-image", response_model=AskResponse)
async def ask_with_image(
    image: UploadFile = File(...),
    question: str = Form(...),
    user_id: str = Form(default="default"),
    user_name: str = Form(default="Clinician"),
    user_qualification: str = Form(default="P&O Professional"),
    user_specialization: str = Form(default="P&O"),
):
    """
    Ask a question with an image AND retrieve from the knowledge base.
    Combines: vision analysis + RAG retrieval + LLM reasoning.

    Example: Upload a socket photo and ask "What type is this and how
    does it compare to designs in my textbooks?"
    """
    contents = await image.read()
    b64_data = base64.standard_b64encode(contents).decode("utf-8")
    ext = (image.filename or "").rsplit(".", 1)[-1].lower()
    media_types = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}
    media_type = media_types.get(ext, "image/jpeg")

    # Step 1: Image analysis
    img_result = analyze_image_from_base64(
        base64_data=b64_data, media_type=media_type,
        question="Describe what you see, focusing on P&O features.",
        user_name=user_name, user_specialization=user_specialization,
    )

    # Step 2: RAG retrieval
    chunks = retrieve(user_id=user_id, query=question)
    text_context = format_context(chunks)

    # Step 3: Combine
    combined = f"IMAGE ANALYSIS:\n{img_result['analysis']}"
    if text_context:
        combined += f"\n\nTEXTBOOK REFERENCES:\n{text_context}"

    # Step 4: Generate
    result = await generate_answer(
        question=question, context=combined,
        user_name=user_name, user_qualification=user_qualification,
        user_specialization=user_specialization,
    )

    sources = []
    seen = set()
    for chunk in chunks:
        key = f"{chunk.get('book_name', '')}|{chunk.get('chapter', '')}|{chunk.get('page', '')}"
        if key not in seen:
            seen.add(key)
            sources.append(SourceRef(
                book_name=chunk.get("book_name", chunk.get("source", "Unknown")),
                chapter=chunk.get("chapter"), section=chunk.get("section"),
                page=chunk.get("page"), relevance=chunk.get("score", 0),
                content_type=chunk.get("content_type", "prose"),
            ))

    return AskResponse(
        answer=result["answer"], sources=sources, model_used=result["model_used"],
        chunks_retrieved=len(chunks),
        tokens_used=result.get("tokens_in", 0) + result.get("tokens_out", 0),
        retrieval_summary=get_retrieval_summary(chunks),
    )
