"""Health check endpoint."""
from fastapi import APIRouter

router = APIRouter()

@router.get("/health")
async def health():
    return {"status": "ok", "service": "ASh API", "version": "1.0.0"}
