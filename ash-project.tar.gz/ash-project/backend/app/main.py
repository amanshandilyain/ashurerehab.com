"""ASh — FastAPI Backend Entry Point"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth, chat, documents, health, vision, admin

app = FastAPI(
    title="ASh — P&O Medical AI Assistant",
    description="RAG-powered AI for Prosthetics & Orthotics professionals",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, tags=["Health"])
app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(documents.router, prefix="/documents", tags=["Documents"])
app.include_router(chat.router, prefix="/chat", tags=["Chat"])
app.include_router(vision.router, prefix="/vision", tags=["Vision"])
app.include_router(admin.router, prefix="/admin", tags=["Admin"])
