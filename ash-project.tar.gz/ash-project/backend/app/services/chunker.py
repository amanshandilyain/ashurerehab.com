"""
Semantic Document Chunker v2
Splits text into meaningful chunks preserving rich metadata:
  - book name, chapter, section, page number
  - chunk position and relationships
  - content type (prose, table, list, heading, clinical_data)

Designed for large medical textbooks (hundreds of MB).
"""
import re
from typing import Optional
from langchain_text_splitters import RecursiveCharacterTextSplitter
from app.config import CHUNK_SIZE, CHUNK_OVERLAP, MAX_CHUNKS_PER_DOCUMENT


# ─── CHAPTER / SECTION DETECTION PATTERNS ────────────────────────────────────
CHAPTER_PATTERNS = [
    re.compile(r"^Chapter\s+(\d+)[:\s.\-—]+(.+)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^CHAPTER\s+(\d+)[:\s.\-—]+(.+)", re.MULTILINE),
    re.compile(r"^(\d+)\.\s+([A-Z][A-Za-z\s&\-:]+)$", re.MULTILINE),
    re.compile(r"^Part\s+(\w+)[:\s.\-—]+(.+)", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^Section\s+(\d+)[:\s.\-—]+(.+)", re.IGNORECASE | re.MULTILINE),
]

SECTION_PATTERNS = [
    re.compile(r"^(\d+\.\d+)\s+(.+)", re.MULTILINE),
    re.compile(r"^([A-Z][A-Z\s&\-:]{4,50})$", re.MULTILINE),
    re.compile(r"^#{1,4}\s+(.+)", re.MULTILINE),
]

PAGE_PATTERNS = [
    re.compile(r"\[Page\s+(\d+)\]"),
    re.compile(r"\[Slide\s+(\d+)\]"),
    re.compile(r"^Page\s+(\d+)\s*$", re.MULTILINE),
    re.compile(r"[-—]\s*(\d+)\s*[-—]"),
]


def chunk_document(
    text: str,
    source_filename: str,
    book_name: str = None,
    chunk_size: int = CHUNK_SIZE,
    chunk_overlap: int = CHUNK_OVERLAP,
) -> list[dict]:
    """
    Split document into semantic chunks with rich metadata.

    Pipeline:
    1. Pre-scan: detect chapters, sections, pages throughout the text
    2. Build position → metadata maps
    3. Chunk with semantic separators (headings → paragraphs → sentences)
    4. Attach nearest metadata to each chunk
    5. Classify content type per chunk
    """
    if not text or len(text.strip()) < 50:
        return []

    if not book_name:
        book_name = _infer_book_name(source_filename)

    # Pre-scan for document structure
    chapter_map = _build_chapter_map(text)
    section_map = _build_section_map(text)
    page_map = _build_page_map(text)

    # Smart splitting with medical-text-aware separators
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=[
            "\n## ", "\n### ", "\n#### ",
            "\nChapter ", "\nCHAPTER ",
            "\n[Page ", "\n[Slide ",
            "\n\n\n", "\n\n", "\n",
            ". ", "; ", ", ", " ",
        ],
        length_function=len,
        is_separator_regex=False,
    )

    raw_chunks = splitter.split_text(text)

    chunks = []
    for i, chunk_text in enumerate(raw_chunks):
        if len(chunk_text.strip()) < 30:
            continue
        if i >= MAX_CHUNKS_PER_DOCUMENT:
            break

        char_pos = text.find(chunk_text[:80])
        if char_pos == -1:
            char_pos = i * chunk_size

        chapter = _lookup_nearest(chapter_map, char_pos)
        section = _lookup_nearest(section_map, char_pos)
        page = _lookup_nearest_page(page_map, char_pos)

        inline_page = _detect_inline_page(chunk_text)
        if inline_page:
            page = inline_page

        content_type = _classify_content(chunk_text)

        metadata = {
            "source": source_filename,
            "book_name": book_name,
            "chapter": chapter.get("title") if chapter else None,
            "chapter_num": chapter.get("num") if chapter else None,
            "section": section.get("title") if section else None,
            "page": page,
            "content_type": content_type,
            "chunk_index": i,
            "total_chunks": min(len(raw_chunks), MAX_CHUNKS_PER_DOCUMENT),
            "char_start": char_pos,
            "char_length": len(chunk_text),
        }
        metadata = {k: v for k, v in metadata.items() if v is not None}

        chunks.append({"text": chunk_text.strip(), "metadata": metadata})

    return chunks


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def _infer_book_name(filename: str) -> str:
    name = filename.rsplit(".", 1)[0]
    name = re.sub(r"^[\d_\-]+", "", name)
    name = name.replace("_", " ").replace("-", " ").strip()
    return name.title() if name else filename


def _build_chapter_map(text: str) -> list[dict]:
    chapters = []
    for pattern in CHAPTER_PATTERNS:
        for match in pattern.finditer(text):
            chapters.append({
                "pos": match.start(),
                "num": match.group(1).strip(),
                "title": match.group(2).strip()[:100],
            })
    chapters.sort(key=lambda x: x["pos"])
    return chapters


def _build_section_map(text: str) -> list[dict]:
    sections = []
    for pattern in SECTION_PATTERNS:
        for match in pattern.finditer(text):
            title = match.group(1).strip() if match.lastindex else match.group(0).strip()
            if 3 < len(title) < 80:
                sections.append({"pos": match.start(), "title": title[:80]})
    sections.sort(key=lambda x: x["pos"])
    return sections


def _build_page_map(text: str) -> list[dict]:
    pages = []
    for pattern in PAGE_PATTERNS:
        for match in pattern.finditer(text):
            try:
                num = int(match.group(1))
                if 0 < num < 10000:
                    pages.append({"pos": match.start(), "num": num})
            except (ValueError, IndexError):
                pass
    pages.sort(key=lambda x: x["pos"])
    return pages


def _lookup_nearest(mapped: list[dict], char_pos: int):
    if not mapped:
        return None
    result = None
    for entry in mapped:
        if entry["pos"] <= char_pos:
            result = entry
        else:
            break
    return result


def _lookup_nearest_page(page_map: list[dict], char_pos: int) -> Optional[int]:
    entry = _lookup_nearest(page_map, char_pos)
    return entry["num"] if entry else None


def _detect_inline_page(text: str) -> Optional[int]:
    for pattern in PAGE_PATTERNS:
        match = pattern.search(text)
        if match:
            try:
                return int(match.group(1))
            except (ValueError, IndexError):
                pass
    return None


def _classify_content(text: str) -> str:
    lines = text.strip().split("\n")
    non_empty = [l.strip() for l in lines if l.strip()]
    if not non_empty:
        return "empty"

    pipe_lines = sum(1 for l in non_empty if "|" in l)
    if pipe_lines > len(non_empty) * 0.4:
        return "table"

    list_starters = sum(1 for l in non_empty if re.match(r"^[\s]*[•\-\*\d]+[.\)]\s", l))
    if list_starters > len(non_empty) * 0.4:
        return "list"

    if len(non_empty) <= 2 and len(text.strip()) < 150:
        return "heading"

    if re.search(r"\d+\s*(degrees?|mm|cm|kg|N|Nm|%)", text):
        return "clinical_data"

    return "prose"
