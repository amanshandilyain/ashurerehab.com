"""
Document Ingestion Service
Reads: PDF, PPTX, DOCX, images (OCR), plain text
Returns: extracted text with metadata
"""
import os
from pathlib import Path
from typing import Optional
import pdfplumber
from pypdf import PdfReader
from pptx import Presentation
from docx import Document as DocxDocument
from PIL import Image
import pytesseract
from pdf2image import convert_from_path


def extract_text(file_path: str) -> dict:
    """
    Master extraction function.
    Detects file type and routes to the right reader.
    Returns: {"text": str, "pages": int, "method": str}
    """
    ext = Path(file_path).suffix.lower()

    extractors = {
        ".pdf": extract_pdf,
        ".pptx": extract_pptx,
        ".ppt": extract_pptx,
        ".docx": extract_docx,
        ".doc": extract_docx,
        ".txt": extract_plaintext,
        ".md": extract_plaintext,
        ".csv": extract_plaintext,
        ".png": extract_image_ocr,
        ".jpg": extract_image_ocr,
        ".jpeg": extract_image_ocr,
        ".gif": extract_image_ocr,
        ".webp": extract_image_ocr,
        ".tiff": extract_image_ocr,
    }

    extractor = extractors.get(ext)
    if not extractor:
        return {"text": "", "pages": 0, "method": "unsupported"}

    return extractor(file_path)


def extract_pdf(file_path: str) -> dict:
    """Extract text from PDF using pdfplumber (layout-aware) with pypdf fallback."""
    text_parts = []
    page_count = 0

    # Try pdfplumber first (better for tables and complex layouts)
    try:
        with pdfplumber.open(file_path) as pdf:
            page_count = len(pdf.pages)
            for i, page in enumerate(pdf.pages):
                page_text = page.extract_text() or ""

                # Also extract tables as structured text
                tables = page.extract_tables()
                for table in tables:
                    if table:
                        for row in table:
                            row_text = " | ".join(str(cell or "") for cell in row)
                            page_text += f"\n{row_text}"

                if page_text.strip():
                    text_parts.append(f"[Page {i+1}]\n{page_text}")

    except Exception:
        # Fallback to pypdf
        try:
            reader = PdfReader(file_path)
            page_count = len(reader.pages)
            for i, page in enumerate(reader.pages):
                page_text = page.extract_text() or ""
                if page_text.strip():
                    text_parts.append(f"[Page {i+1}]\n{page_text}")
        except Exception:
            pass

    full_text = "\n\n".join(text_parts)

    # If very little text extracted, try OCR (scanned PDF)
    if len(full_text.strip()) < 100 and page_count > 0:
        ocr_result = extract_scanned_pdf(file_path)
        if len(ocr_result["text"]) > len(full_text):
            return ocr_result

    return {"text": full_text, "pages": page_count, "method": "pdfplumber"}


def extract_scanned_pdf(file_path: str) -> dict:
    """OCR for scanned/image-based PDFs."""
    try:
        images = convert_from_path(file_path, dpi=200)
        text_parts = []
        for i, img in enumerate(images):
            page_text = pytesseract.image_to_string(img)
            if page_text.strip():
                text_parts.append(f"[Page {i+1} — OCR]\n{page_text}")
        return {
            "text": "\n\n".join(text_parts),
            "pages": len(images),
            "method": "ocr",
        }
    except Exception as e:
        return {"text": "", "pages": 0, "method": f"ocr_failed: {e}"}


def extract_pptx(file_path: str) -> dict:
    """Extract text from PowerPoint presentations."""
    try:
        prs = Presentation(file_path)
        text_parts = []
        for i, slide in enumerate(prs.slides):
            slide_texts = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        para_text = paragraph.text.strip()
                        if para_text:
                            slide_texts.append(para_text)
                # Tables in slides
                if shape.has_table:
                    for row in shape.table.rows:
                        row_text = " | ".join(cell.text.strip() for cell in row.cells)
                        if row_text.strip():
                            slide_texts.append(row_text)
            if slide_texts:
                text_parts.append(f"[Slide {i+1}]\n" + "\n".join(slide_texts))

        return {
            "text": "\n\n".join(text_parts),
            "pages": len(prs.slides),
            "method": "python-pptx",
        }
    except Exception as e:
        return {"text": "", "pages": 0, "method": f"pptx_failed: {e}"}


def extract_docx(file_path: str) -> dict:
    """Extract text from Word documents."""
    try:
        doc = DocxDocument(file_path)
        text_parts = []
        for para in doc.paragraphs:
            if para.text.strip():
                text_parts.append(para.text)

        # Extract tables
        for table in doc.tables:
            for row in table.rows:
                row_text = " | ".join(cell.text.strip() for cell in row.cells)
                if row_text.strip():
                    text_parts.append(row_text)

        return {
            "text": "\n".join(text_parts),
            "pages": max(1, len(text_parts) // 30),  # Estimate
            "method": "python-docx",
        }
    except Exception as e:
        return {"text": "", "pages": 0, "method": f"docx_failed: {e}"}


def extract_image_ocr(file_path: str) -> dict:
    """OCR for standalone images."""
    try:
        img = Image.open(file_path)
        text = pytesseract.image_to_string(img)
        return {"text": text, "pages": 1, "method": "tesseract_ocr"}
    except Exception as e:
        return {"text": "", "pages": 0, "method": f"ocr_failed: {e}"}


def extract_plaintext(file_path: str) -> dict:
    """Read plain text files."""
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        return {"text": text, "pages": 1, "method": "plaintext"}
    except Exception as e:
        return {"text": "", "pages": 0, "method": f"text_failed: {e}"}
