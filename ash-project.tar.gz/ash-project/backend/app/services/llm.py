"""
LLM Service v3
- Clinical Reasoning Mode: structured Problem → Causes → Explanation → Conclusion
- Smart model routing: Haiku (fast) → Sonnet (deep)
- Conversation memory support
- Synthesis-enforced prompts
"""
import re
import anthropic
from app.config import ANTHROPIC_API_KEY, HAIKU_MODEL, SONNET_MODEL

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

COMPLEX_INDICATORS = [
    "compare", "difference", "explain why", "mechanism",
    "biomechanics", "contraindication", "differential",
    "analyze", "evaluate", "critique", "relationship between",
    "step by step", "detailed", "comprehensive", "in depth",
]

# Clinical question indicators — triggers structured reasoning mode
CLINICAL_INDICATORS = [
    "patient", "presenting with", "complains of", "gait deviation",
    "what could cause", "why is the patient", "how to treat",
    "what would you recommend", "differential diagnosis",
    "pressure sore", "pain at", "discomfort", "alignment issue",
    "socket problem", "poor fit", "skin breakdown", "pistoning",
    "genu recurvatum", "foot drop", "knee instability",
    "what should i do", "how to manage", "clinical", "prescribe",
    "contraindication", "indication for", "when to use",
    "what causes", "why does", "troubleshoot",
]


def is_clinical_question(question: str) -> bool:
    """Detect if a question requires structured clinical reasoning."""
    q_lower = question.lower()
    hits = sum(1 for ind in CLINICAL_INDICATORS if ind in q_lower)
    return hits >= 1


def build_system_prompt(
    user_name: str, user_qualification: str, user_specialization: str,
    has_context: bool, clinical_mode: bool = False,
) -> str:
    """Build ASh's system prompt with synthesis + optional clinical reasoning."""

    clinical_reasoning = """

CLINICAL REASONING MODE (ACTIVE):
You've detected a clinical question. Structure your response as a medical consultant would:

**Problem** — Clearly restate the clinical issue in 1-2 sentences. What exactly is going on?

**Possible Causes** — List the most likely causes ranked by probability. For each:
  • Name the cause
  • Briefly explain the mechanism (why this happens biomechanically/physiologically)

**Explanation** — Deep dive into the most probable cause(s):
  • Connect the dots between the patient's presentation and the underlying pathology
  • Explain the biomechanical chain of events
  • Reference relevant anatomy, kinesiology, or materials science
  • Cite your sources naturally if documents were provided

**Conclusion** — Clear, actionable answer:
  • What to do (clinical recommendation)
  • What to watch for (red flags or important considerations)
  • When to escalate or refer

Keep this structure but write conversationally — like a senior clinician teaching a colleague, not a textbook.""" if clinical_mode else ""

    synthesis_rules = """

DOCUMENT SYNTHESIS PROTOCOL (MANDATORY when documents are provided):
Step 1 — READ: Absorb the retrieved context fully.
Step 2 — UNDERSTAND: Identify the core concepts, principles, and clinical reasoning.
Step 3 — EXTRACT: Pull out key ideas, relationships, and practical implications.
Step 4 — REWRITE: Explain in YOUR OWN words.

STRICT RULES:
• NEVER copy sentences from the documents — not even short phrases
• NEVER say "the document states" — teach the concept directly
• Add clinical reasoning beyond what sources explicitly state
• Explain WHY, not just WHAT
• Cite sources naturally like "from your Atlas of Prosthetics (p.42)..." but NEVER quote""" if has_context else ""

    return f"""You are ASh — you ARE Claude by Anthropic, with all of Claude's intelligence, reasoning, and capabilities. Your name is ASh. You specialize in Prosthetics & Orthotics but can help with anything. You are a professional medical consultant who explains concepts clearly and practically.

User: {user_name} ({user_qualification}, {user_specialization})

CORE BEHAVIOR:
- Be warm, direct, conversational — a brilliant senior colleague
- Teach concepts, don't recite textbooks
- Use **bold** for key terms and • for lists when helpful
- Never explain how you'll answer — just answer
- Always add your own clinical insight and reasoning
- Remember the conversation context — refer back to previous topics naturally
- If the user asks a follow-up, connect it to what was discussed before{clinical_reasoning}{synthesis_rules}"""


def is_complex_question(question: str, num_context_chunks: int) -> bool:
    """Determine if a question needs Sonnet (deep) or Haiku (fast)."""
    q_lower = question.lower()

    # Long questions are usually complex
    if len(question) > 150:
        return True

    # Check for complexity indicators
    if any(indicator in q_lower for indicator in COMPLEX_INDICATORS):
        return True

    # Many relevant chunks = rich context = needs deeper reasoning
    if num_context_chunks >= 4:
        return True

    return False


async def generate_answer(
    question: str,
    context: str,
    user_name: str = "Clinician",
    user_qualification: str = "P&O Professional",
    user_specialization: str = "P&O",
    conversation_history: list[dict] = None,
) -> dict:
    """
    Generate an answer using Claude.

    Routes to Haiku (fast, ~1-2s) for simple questions,
    Sonnet (deep, ~3-5s) for complex ones.
    Falls back to Sonnet if Haiku fails.

    Returns: {"answer": str, "model_used": str, "sources": list}
    """
    num_chunks = context.count("---") + 1 if context else 0
    use_sonnet = is_complex_question(question, num_chunks)
    clinical_mode = is_clinical_question(question)

    # Clinical questions always use Sonnet (deeper reasoning needed)
    if clinical_mode:
        use_sonnet = True

    # Build messages
    messages = []

    if context:
        messages.append({
            "role": "user",
            "content": f"""Here are relevant excerpts retrieved from the user's uploaded textbooks:

{context}

IMPORTANT: These excerpts are RAW REFERENCE MATERIAL — they are NOT your answer.
Your job is to:
1. Read and deeply understand the concepts
2. Extract key principles, relationships, clinical implications
3. Formulate your answer entirely in your own words
4. Add reasoning, clinical context, practical interpretation
5. Cite the source file naturally but NEVER quote text from it""",
        })
        messages.append({
            "role": "assistant",
            "content": "I've studied the reference material. I'll teach the concepts in my own words. What's your question?",
        })

    # Add conversation history (supports follow-ups and contextual memory)
    if conversation_history:
        messages.extend(conversation_history[-14:])  # Keep last 7 exchanges

    messages.append({"role": "user", "content": question})

    system_prompt = build_system_prompt(
        user_name, user_qualification, user_specialization,
        bool(context), clinical_mode=clinical_mode,
    )

    # Try primary model
    primary_model = SONNET_MODEL if use_sonnet else HAIKU_MODEL
    fallback_model = SONNET_MODEL if primary_model == HAIKU_MODEL else None

    try:
        response = client.messages.create(
            model=primary_model,
            max_tokens=1500,
            system=system_prompt,
            messages=messages,
        )
        answer = "".join(
            block.text for block in response.content if block.type == "text"
        )
        return {
            "answer": answer,
            "model_used": primary_model,
            "tokens_in": response.usage.input_tokens,
            "tokens_out": response.usage.output_tokens,
        }

    except Exception as e:
        if fallback_model:
            # Fallback to Sonnet
            try:
                response = client.messages.create(
                    model=fallback_model,
                    max_tokens=1500,
                    system=system_prompt,
                    messages=messages,
                )
                answer = "".join(
                    block.text for block in response.content if block.type == "text"
                )
                return {
                    "answer": answer,
                    "model_used": f"{fallback_model} (fallback)",
                    "tokens_in": response.usage.input_tokens,
                    "tokens_out": response.usage.output_tokens,
                }
            except Exception as e2:
                return {
                    "answer": f"I encountered an error: {str(e2)}",
                    "model_used": "error",
                    "tokens_in": 0,
                    "tokens_out": 0,
                }
        else:
            return {
                "answer": f"I encountered an error: {str(e)}",
                "model_used": "error",
                "tokens_in": 0,
                "tokens_out": 0,
            }
