"""
Vision & Image Analysis Service
Combines OCR + Claude Vision for:
  - Medical textbook diagrams
  - Prosthetic/orthotic design images
  - Scanned pages, X-rays, gait screenshots
"""
import base64
import os
from pathlib import Path
from PIL import Image
import pytesseract
import anthropic
from app.config import ANTHROPIC_API_KEY, VISION_MODEL, VISION_MAX_IMAGE_SIZE_MB, SUPPORTED_IMAGE_TYPES

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)


def analyze_image(
    image_path: str,
    question: str = "",
    user_name: str = "Clinician",
    user_qualification: str = "",
    user_specialization: str = "P&O",
    include_ocr: bool = True,
) -> dict:
    """
    Full pipeline: OCR + Claude Vision.
    Returns: {"analysis": str, "ocr_text": str, "model_used": str}
    """
    ext = Path(image_path).suffix.lower()
    if ext not in SUPPORTED_IMAGE_TYPES:
        return {"analysis": f"Unsupported type: {ext}", "ocr_text": "", "model_used": "none"}

    size_mb = os.path.getsize(image_path) / (1024 * 1024)
    if size_mb > VISION_MAX_IMAGE_SIZE_MB:
        return {"analysis": f"Too large ({size_mb:.1f}MB)", "ocr_text": "", "model_used": "none"}

    # OCR
    ocr_text = ""
    if include_ocr:
        try:
            img = Image.open(image_path)
            if img.mode != "RGB":
                img = img.convert("RGB")
            ocr_text = pytesseract.image_to_string(img, config="--psm 6").strip()
        except Exception:
            ocr_text = ""

    # Encode
    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")

    mime_map = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".gif": "image/gif", ".webp": "image/webp", ".tiff": "image/tiff"}
    media_type = mime_map.get(ext, "image/png")

    ocr_note = f"\n\nOCR text found: {ocr_text[:2000]}" if ocr_text and len(ocr_text) > 10 else ""
    user_q = question.strip() or "Analyze this image in detail."

    system = f"""You are ASh — a P&O expert with Claude's full vision capabilities.
User: {user_name} ({user_qualification}, {user_specialization})

WHEN ANALYZING IMAGES:
- Identify what the image shows (anatomy, prosthetic component, orthotic device, diagram, X-ray, gait screenshot)
- Describe relevant clinical/biomechanical features
- If prosthetic/orthotic: comment on socket shape, alignment, materials, fit indicators
- If anatomical diagram: identify structures, explain relationships, note clinical relevance
- If gait analysis: describe phase, deviations, clinical implications
- If scanned textbook: summarize content in your own words
- Connect observations to P&O clinical practice
- Be specific — name structures, angles, components{ocr_note}"""

    try:
        response = client.messages.create(
            model=VISION_MODEL, max_tokens=1500, system=system,
            messages=[{"role": "user", "content": [
                {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}},
                {"type": "text", "text": user_q},
            ]}],
        )
        analysis = "".join(b.text for b in response.content if b.type == "text")
        return {"analysis": analysis, "ocr_text": ocr_text, "model_used": VISION_MODEL,
                "tokens_in": response.usage.input_tokens, "tokens_out": response.usage.output_tokens}
    except Exception as e:
        fallback = f"Vision unavailable ({e}). "
        if ocr_text:
            fallback += f"OCR extracted:\n\n{ocr_text}"
        return {"analysis": fallback, "ocr_text": ocr_text, "model_used": "ocr_fallback"}


def analyze_image_bytes(
    image_bytes: bytes, media_type: str, question: str = "",
    user_name: str = "Clinician", user_qualification: str = "", user_specialization: str = "P&O",
) -> dict:
    """Analyze image from raw bytes (direct upload, no disk save)."""
    b64 = base64.b64encode(image_bytes).decode("utf-8")
    user_q = question.strip() or "Analyze this image in detail."

    system = f"""You are ASh — a P&O expert with full vision. Analyze with clinical expertise.
User: {user_name} ({user_qualification}, {user_specialization})
Identify structures, components, deviations. Explain clinical significance. Be specific."""

    try:
        response = client.messages.create(
            model=VISION_MODEL, max_tokens=1500, system=system,
            messages=[{"role": "user", "content": [
                {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}},
                {"type": "text", "text": user_q},
            ]}],
        )
        return {"analysis": "".join(b.text for b in response.content if b.type == "text"),
                "ocr_text": "", "model_used": VISION_MODEL}
    except Exception as e:
        return {"analysis": f"Vision failed: {e}", "ocr_text": "", "model_used": "error"}
