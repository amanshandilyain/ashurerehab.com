"""
Retriever v2 — Hybrid Semantic + Keyword Search
Optimized for large knowledge bases with:
  - Semantic search via embeddings (understands meaning)
  - Keyword boost (catches exact medical terms embeddings might miss)
  - MMR diversity (avoids returning 6 chunks from the same paragraph)
  - Metadata-aware scoring (boosts chunks with chapter/page matches)
  - Rich source formatting with book, chapter, page
  - Minimum relevance threshold (drops noise)
"""
import re
from app.services.embedder import get_or_create_collection, embed_single, openai_client
from app.config import TOP_K_CHUNKS, RETRIEVAL_CANDIDATES, MIN_RELEVANCE_SCORE


def retrieve(
    user_id: str,
    query: str,
    top_k: int = TOP_K_CHUNKS,
    candidates: int = RETRIEVAL_CANDIDATES,
) -> list[dict]:
    """
    Hybrid retrieval pipeline:
    1. Semantic search — find candidates by embedding similarity
    2. Keyword boost — re-score candidates that contain exact query terms
    3. MMR diversity — ensure results come from different sections/pages
    4. Metadata boost — prefer chunks with detected chapter/page metadata
    5. Threshold — drop anything below MIN_RELEVANCE_SCORE
    """
    collection = get_or_create_collection(user_id)
    count = collection.count()

    if count == 0:
        return []

    n_fetch = min(candidates, count)

    # ─── STEP 1: Semantic search ─────────────────────────────────────────
    if openai_client:
        query_embedding = embed_single(query)
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=n_fetch,
            include=["documents", "metadatas", "distances"],
        )
    else:
        results = collection.query(
            query_texts=[query],
            n_results=n_fetch,
            include=["documents", "metadatas", "distances"],
        )

    if not results["documents"] or not results["documents"][0]:
        return []

    # ─── STEP 2: Score with keyword boosting ─────────────────────────────
    query_terms = set(re.findall(r'\b\w{3,}\b', query.lower()))
    # Extract key medical terms (longer words are more specific)
    key_terms = {t for t in query_terms if len(t) >= 5}

    scored_chunks = []
    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        # Base semantic score (cosine similarity)
        semantic_score = max(0.0, 1.0 - dist) if dist <= 2.0 else 0.0

        # Keyword boost: reward chunks containing exact query terms
        doc_lower = doc.lower()
        keyword_hits = sum(1 for t in query_terms if t in doc_lower)
        key_term_hits = sum(1 for t in key_terms if t in doc_lower)
        keyword_boost = (keyword_hits * 0.02) + (key_term_hits * 0.04)

        # Metadata boost: prefer chunks with rich structure
        meta_boost = 0.0
        if meta.get("chapter"):
            meta_boost += 0.02
        if meta.get("page"):
            meta_boost += 0.01
        if meta.get("content_type") == "prose":
            meta_boost += 0.01  # Prefer explanatory text over tables/headings

        # Combined score
        final_score = semantic_score + keyword_boost + meta_boost

        scored_chunks.append({
            "text": doc,
            "source": meta.get("source", "Unknown"),
            "book_name": meta.get("book_name", meta.get("source", "Unknown")),
            "chapter": meta.get("chapter"),
            "chapter_num": meta.get("chapter_num"),
            "section": meta.get("section"),
            "page": meta.get("page"),
            "content_type": meta.get("content_type", "prose"),
            "chunk_index": meta.get("chunk_index", 0),
            "document_id": meta.get("document_id", ""),
            "semantic_score": round(semantic_score, 4),
            "keyword_hits": keyword_hits,
            "score": round(final_score, 4),
        })

    # Sort by combined score
    scored_chunks.sort(key=lambda x: x["score"], reverse=True)

    # ─── STEP 3: MMR Diversity Filter ────────────────────────────────────
    # Avoid returning multiple chunks from the exact same location
    selected = []
    seen_locations = set()

    for chunk in scored_chunks:
        if chunk["score"] < MIN_RELEVANCE_SCORE:
            continue

        # Location key: source + chapter + page (rough dedup)
        loc_key = f"{chunk['source']}|{chunk.get('chapter', '')}|{chunk.get('page', '')}|{chunk['chunk_index'] // 3}"

        # Allow max 2 chunks from the same location
        loc_count = sum(1 for s in selected if f"{s['source']}|{s.get('chapter', '')}|{s.get('page', '')}" == f"{chunk['source']}|{chunk.get('chapter', '')}|{chunk.get('page', '')}")
        if loc_count >= 2:
            continue

        # Text overlap check: skip if >60% similar to already selected
        skip = False
        chunk_words = set(chunk["text"].lower().split()[:50])
        for s in selected:
            s_words = set(s["text"].lower().split()[:50])
            overlap = len(chunk_words & s_words) / max(len(chunk_words | s_words), 1)
            if overlap > 0.6:
                skip = True
                break
        if skip:
            continue

        selected.append(chunk)
        if len(selected) >= top_k:
            break

    return selected


def format_context(chunks: list[dict]) -> str:
    """
    Format retrieved chunks into rich context for the LLM.
    Includes book name, chapter, page — so the LLM can cite properly.
    """
    if not chunks:
        return ""

    parts = []
    for i, chunk in enumerate(chunks):
        # Build rich source header
        header_parts = []
        if chunk.get("book_name"):
            header_parts.append(chunk["book_name"])
        if chunk.get("chapter"):
            ch = chunk["chapter"]
            if chunk.get("chapter_num"):
                ch = f"Ch.{chunk['chapter_num']}: {ch}"
            header_parts.append(ch)
        if chunk.get("section"):
            header_parts.append(f"§ {chunk['section']}")
        if chunk.get("page"):
            header_parts.append(f"Page {chunk['page']}")

        source_line = " → ".join(header_parts) if header_parts else chunk.get("source", "Unknown")
        score_pct = f"{chunk['score']:.0%}" if chunk.get("score") else "N/A"
        content_tag = chunk.get("content_type", "prose")

        header = f"[Source: {source_line} | Relevance: {score_pct} | Type: {content_tag}]"
        parts.append(f"{header}\n{chunk['text']}")

    return "\n\n" + "─" * 40 + "\n\n".join(parts)


def get_retrieval_summary(chunks: list[dict]) -> dict:
    """
    Generate a summary of what was retrieved — useful for debugging
    and for showing users where answers came from.
    """
    if not chunks:
        return {"sources": [], "total_chunks": 0}

    sources = {}
    for c in chunks:
        key = c.get("book_name", c.get("source", "Unknown"))
        if key not in sources:
            sources[key] = {
                "book": key,
                "chapters": set(),
                "pages": set(),
                "chunks": 0,
                "avg_relevance": 0.0,
            }
        sources[key]["chunks"] += 1
        sources[key]["avg_relevance"] += c.get("score", 0)
        if c.get("chapter"):
            sources[key]["chapters"].add(c["chapter"])
        if c.get("page"):
            sources[key]["pages"].add(c["page"])

    source_list = []
    for s in sources.values():
        s["avg_relevance"] = round(s["avg_relevance"] / max(s["chunks"], 1), 3)
        s["chapters"] = sorted(s["chapters"])
        s["pages"] = sorted(s["pages"])
        source_list.append(s)

    source_list.sort(key=lambda x: x["avg_relevance"], reverse=True)

    return {
        "sources": source_list,
        "total_chunks": len(chunks),
        "top_score": chunks[0]["score"] if chunks else 0,
    }
