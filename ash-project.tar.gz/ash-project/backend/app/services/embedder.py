"""
Embedding Service v2
Optimized for large knowledge bases (hundreds of MB):
  - Batch embedding (64 at a time vs 1-by-1)
  - Chunked upserts (avoids ChromaDB memory issues)
  - Embedding cache to avoid re-embedding identical text
  - Graceful fallback to ChromaDB's built-in embedder
"""
import hashlib
import chromadb
from openai import OpenAI
from app.config import (
    CHROMA_PERSIST_DIR, OPENAI_API_KEY,
    EMBEDDING_BATCH_SIZE, EMBEDDING_MODEL,
    CHROMA_HNSW_M, CHROMA_HNSW_EF_CONSTRUCT, CHROMA_HNSW_EF_SEARCH,
)


# ─── CLIENTS ─────────────────────────────────────────────────────────────────
chroma_client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)
openai_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

# Simple in-memory embedding cache (hash → vector)
# Prevents re-embedding identical chunks across document re-uploads
_embedding_cache: dict[str, list[float]] = {}
_CACHE_MAX = 50000  # Cap to prevent memory bloat


def get_or_create_collection(user_id: str) -> chromadb.Collection:
    """Get or create an isolated ChromaDB collection per user with tuned HNSW index."""
    name = f"ash_{user_id}"
    name = "".join(c if c.isalnum() or c == "_" else "_" for c in name)
    if not name[0].isalnum():
        name = "u" + name
    name = name[:63]
    return chroma_client.get_or_create_collection(
        name=name,
        metadata={
            "hnsw:space": "cosine",
            "hnsw:M": CHROMA_HNSW_M,
            "hnsw:construction_ef": CHROMA_HNSW_EF_CONSTRUCT,
            "hnsw:search_ef": CHROMA_HNSW_EF_SEARCH,
        },
    )


# ─── EMBEDDING ───────────────────────────────────────────────────────────────

def _text_hash(text: str) -> str:
    """Fast hash for cache lookup."""
    return hashlib.md5(text.encode()).hexdigest()


def embed_single(text: str) -> list[float] | None:
    """Embed a single text string, using cache when possible."""
    if not openai_client:
        return None

    h = _text_hash(text)
    if h in _embedding_cache:
        return _embedding_cache[h]

    response = openai_client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=text,
    )
    vec = response.data[0].embedding

    if len(_embedding_cache) < _CACHE_MAX:
        _embedding_cache[h] = vec

    return vec


def embed_batch(texts: list[str]) -> list[list[float]] | None:
    """
    Batch-embed multiple texts in one API call.
    OpenAI supports up to 2048 texts per call; we batch at EMBEDDING_BATCH_SIZE.
    Returns None if no OpenAI client (ChromaDB will auto-embed).
    """
    if not openai_client or not texts:
        return None

    all_embeddings = [None] * len(texts)
    uncached_indices = []
    uncached_texts = []

    # Check cache first
    for i, text in enumerate(texts):
        h = _text_hash(text)
        if h in _embedding_cache:
            all_embeddings[i] = _embedding_cache[h]
        else:
            uncached_indices.append(i)
            uncached_texts.append(text)

    # Batch-embed uncached texts
    for batch_start in range(0, len(uncached_texts), EMBEDDING_BATCH_SIZE):
        batch = uncached_texts[batch_start:batch_start + EMBEDDING_BATCH_SIZE]
        batch_indices = uncached_indices[batch_start:batch_start + EMBEDDING_BATCH_SIZE]

        response = openai_client.embeddings.create(
            model=EMBEDDING_MODEL,
            input=batch,
        )

        for j, data in enumerate(response.data):
            idx = batch_indices[j]
            vec = data.embedding
            all_embeddings[idx] = vec

            if len(_embedding_cache) < _CACHE_MAX:
                _embedding_cache[_text_hash(batch[j])] = vec

    return all_embeddings


# ─── STORAGE ─────────────────────────────────────────────────────────────────

def store_chunks(user_id: str, chunks: list[dict], document_id: str) -> int:
    """
    Store chunks with embeddings in ChromaDB.
    Uses batch embedding and chunked upserts for scale.

    Handles thousands of chunks per document efficiently.
    """
    if not chunks:
        return 0

    collection = get_or_create_collection(user_id)

    # Prepare all data
    ids = [f"{document_id}_c{i}" for i in range(len(chunks))]
    documents = [c["text"] for c in chunks]
    metadatas = []
    for c in chunks:
        meta = {**c["metadata"], "document_id": document_id}
        # ChromaDB metadata: must be str/int/float/bool, no None
        clean = {}
        for k, v in meta.items():
            if v is None:
                continue
            if isinstance(v, (str, int, float, bool)):
                clean[k] = v
            else:
                clean[k] = str(v)
        metadatas.append(clean)

    # Batch embed
    embeddings = embed_batch(documents)

    # Chunked upserts (ChromaDB can choke on >5000 items at once)
    UPSERT_BATCH = 500
    stored = 0

    for start in range(0, len(ids), UPSERT_BATCH):
        end = start + UPSERT_BATCH
        batch_ids = ids[start:end]
        batch_docs = documents[start:end]
        batch_meta = metadatas[start:end]

        kwargs = {
            "ids": batch_ids,
            "documents": batch_docs,
            "metadatas": batch_meta,
        }

        if embeddings:
            batch_emb = embeddings[start:end]
            if all(e is not None for e in batch_emb):
                kwargs["embeddings"] = batch_emb

        collection.upsert(**kwargs)
        stored += len(batch_ids)

    return stored


def delete_document_chunks(user_id: str, document_id: str) -> int:
    """Remove all chunks for a specific document."""
    collection = get_or_create_collection(user_id)
    try:
        results = collection.get(where={"document_id": document_id})
        if results["ids"]:
            collection.delete(ids=results["ids"])
        return len(results["ids"])
    except Exception:
        return 0


def get_collection_stats(user_id: str) -> dict:
    """Get stats about a user's vector collection."""
    collection = get_or_create_collection(user_id)
    return {
        "total_chunks": collection.count(),
        "collection_name": collection.name,
        "embedding_cache_size": len(_embedding_cache),
    }
