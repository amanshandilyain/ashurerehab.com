"""ASh Configuration — loads from .env"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).parent.parent

# API Keys
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Database
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR / 'data' / 'ash.db'}")

# Vector Store — tuned for 1GB+ knowledge bases
CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", str(BASE_DIR / "data" / "chromadb"))
CHROMA_HNSW_M = 32               # Graph connectivity (higher = better recall, more RAM)
CHROMA_HNSW_EF_CONSTRUCT = 200   # Build-time search depth (higher = better index quality)
CHROMA_HNSW_EF_SEARCH = 100      # Query-time search depth (higher = better recall)

# Uploads
UPLOAD_DIR = os.getenv("UPLOAD_DIR", str(BASE_DIR / "data" / "uploads"))
MAX_UPLOAD_SIZE_MB = int(os.getenv("MAX_UPLOAD_SIZE_MB", "200"))
BULK_UPLOAD_DIR = os.getenv("BULK_UPLOAD_DIR", str(BASE_DIR / "data" / "books"))

# Auth
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_DAYS = int(os.getenv("JWT_EXPIRY_DAYS", "30"))

# LLM Models
HAIKU_MODEL = "claude-haiku-4-5-20251001"
SONNET_MODEL = "claude-sonnet-4-20250514"

# Chunking — optimized for medical textbooks
CHUNK_SIZE = 1500
CHUNK_OVERLAP = 200

# Retrieval
TOP_K_CHUNKS = 6
RETRIEVAL_CANDIDATES = 20
MIN_RELEVANCE_SCORE = 0.15

# Embedding — batch for scale
EMBEDDING_BATCH_SIZE = 64
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")

# Scale limits
MAX_CHUNKS_PER_DOCUMENT = 5000   # ~7.5M chars per doc
MAX_CONCURRENT_INGESTIONS = 4     # Parallel doc processing
MAX_KNOWLEDGE_BASE_CHUNKS = 500000  # ~750M chars total capacity

# Vision / Image Analysis
VISION_MODEL = SONNET_MODEL       # Sonnet has strong vision capabilities
VISION_MAX_IMAGE_SIZE_MB = 20
SUPPORTED_IMAGE_TYPES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".tiff", ".bmp"}

# Ensure directories exist
for d in [UPLOAD_DIR, CHROMA_PERSIST_DIR, BULK_UPLOAD_DIR]:
    Path(d).mkdir(parents=True, exist_ok=True)
